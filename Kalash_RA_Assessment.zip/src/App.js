import { useEffect, useState } from 'react';
import './App.css';

const formatNumber = (number) => new Intl.NumberFormat("en", { minimumFractionDigits: 2 }).format(number);
const sortOn = (arr, prop) => arr.sort(
  function (a, b) {
    if (a[prop] < b[prop]) {
      return -1;
    } else if (a[prop] > b[prop]) {
      return 1;
    } else {
      return 0;
    }
  }
);

function App() {
  const [stores, setStores] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [finalRevenue, setFinalRevenue] = useState(0);
  const [input, setInput] = useState("");
  const [filtered, setFiltered] = useState([]);

  useEffect(() => {
    const branch1 = require('./api/branch1.json');
    const branch2 = require('./api/branch2.json');
    const branch3 = require('./api/branch3.json');

    const all = [branch1.products, branch2.products, branch3.products]
    let unsorted = [];
    let finalProducts = [];

    for (let i = 0; all.length !== 0; i++) {
      let j = 0;
      while (j < all.length) {
        if (i >= all[j].length) {
          all.splice(j, 1);
        } else {

          unsorted.push({
            name: all[j][i].name,
            revenue: all[j][i].unitPrice * all[j][i].sold
          });
          j += 1;
        }
      }
    }

    sortOn(unsorted, "name");

    var holder = {};

    unsorted.forEach(function (d) {
      if (holder.hasOwnProperty(d.name)) {
        holder[d.name] = holder[d.name] + d.revenue;
        formatNumber(holder[d.name])
      } else {
        holder[d.name] = d.revenue;
      }
    });

    for (var prop in holder) {
      finalProducts.push({ name: prop, revenue: holder[prop] });
    }

    function myFunc() {
      setStores(finalProducts)
        setIsLoading(false)
      console.log('check state in api', isLoading);
    }
    myFunc();
  //  const allPromise = Promise.all([
  //     fetch('http://localhost:3000/api/branch1.json'),
  //     fetch('http://localhost:3000/api/branch2.json'),
  //     fetch('http://localhost:3000/api/branch3.json')
  //   ])
    
  //   allPromise.then(data => {

  //     const branch1 = data[0].products;
  //     const branch2 = data[1].products;
  //     const branch3 = data[2].products;


  //     const all = [branch1, branch2, branch3];
  //     let unsorted = [];
  //     let finalProducts = [];

  //     for (let i = 0; all.length !== 0; i++) {
  //       let j = 0;
  //       while (j < all.length) {
  //         if (i >= all[j].length) {
  //           all.splice(j, 1);
  //         } else {

  //           unsorted.push({
  //             name: all[j][i].name,
  //             revenue: all[j][i].unitPrice * all[j][i].sold
  //           });
  //           j += 1;
  //         }
  //       }
  //     }

  //     sortOn(unsorted, "name");

  //     var holder = {};

  //     unsorted.forEach(function (d) {
  //       if (holder.hasOwnProperty(d.name)) {
  //         holder[d.name] = holder[d.name] + d.revenue;
  //         formatNumber(holder[d.name])
  //       } else {
  //         holder[d.name] = d.revenue;
  //       }
  //     });

  //     for (var prop in holder) {
  //       finalProducts.push({ name: prop, revenue: holder[prop] });
  //     }


  //     setStores(finalProducts)
  //     setIsLoading(false)
  //     console.log('check state in api', isLoading);
  //   }).catch(error => {
  //     console.log(error);
  //   });
  }, []);


  const getValueInput = (e) => {
    const inputValue = e.target.value;

    setInput(inputValue);
    filterNames(inputValue);
  }

  const filterNames = (inputValue) => {
    let finalStore = stores;
    setFiltered(finalStore.filter(item =>
      item.name.toLowerCase().includes(inputValue.toLowerCase()))
    )
  }

  const displayTotalRev = () => {
    let finalStore = stores;
    let filteredStore = filtered;
    let sum;

    finalStore.reduce(function (prev, current) {
      sum = prev + +current.revenue;
      return sum
    }, 0);

    if (filteredStore.length === 0) {
      finalStore.reduce(function (prev, current) {
        sum = prev + +current.revenue;
        return sum
      }, 0);
    } else {
      filteredStore.reduce(function (prev, current) {
        sum = prev + +current.revenue;
        return sum
      }, 0);
    }

    return (
      <tr>
        <td>Total</td>
        <td>{formatNumber(sum)}</td>
      </tr>
    )
  }

  const renderTableData = () => {
    let filteredStore = filtered;

    let finalStore = stores;

    if (filteredStore.length === 0) {
      return finalStore.map((store) => {

        return (
          <tr key={store.name}>
            <td>{store.name}</td>
            <td>{formatNumber(store.revenue)}</td>
          </tr>
        )
      })
    } else {
      return filteredStore.map((store) => {

        return (
          <tr key={store.name}>
            <td>{store.name}</td>
            <td>{formatNumber(store.revenue)}</td>
          </tr>
        )
      })
    }
  }

  return (
    <div className="product-list">
      <label>Search Products</label>
      <input type="text" onChange={getValueInput}></input>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Revenue</th>
          </tr>
        </thead>
        <tbody>
          {renderTableData()}
        </tbody>
        <tfoot>
          {displayTotalRev()}
        </tfoot>
      </table>
    </div>
  );
}

export default App;
